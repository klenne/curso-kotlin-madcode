package br.com.klenne.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener, View.OnLongClickListener {
    override fun onLongClick(v: View?): Boolean {
        val id = v!!.id
        if (id == R.id.btn_verificar) {
            txv_boaTarde.text = "Boa Tarde"

        }
        return true
    }
    var controle=1
    override fun onClick(v: View?) {
        val id = v!!.id

        if (id == R.id.btn_verificar) {
            if(controle==1){
                txv_boaTarde.text = "Olá Guilherme"
                controle=0
            }else{
                txv_boaTarde.text = "Hello World!"
                controle=1
            }

        }

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        /*
        btn_verificar.setOnClickListener {
            txv_boaTarde.text="GuiGui"
            */
        btn_verificar.setOnClickListener(this)
        btn_verificar.setOnLongClickListener(this)
    }
    /*
    fun verificar(view: View) {
        txv_boaTarde.text="Olá, MUNDOO!"
    }
    */


}


