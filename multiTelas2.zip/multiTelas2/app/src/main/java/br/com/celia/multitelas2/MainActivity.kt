package br.com.celia.multitelas2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn_verificar.setOnClickListener {

            var nome = edt_nome.text.toString().trim()
            var senha = edt_senha.text.toString().trim()

            if(nome.isNotEmpty()&&senha.isNotEmpty()){
                val intent = Intent(this,Tela2::class.java)
                intent.putExtra("Nome",nome)
                startActivity(intent)
            }else{
                Toast.makeText(this,"Digite as informações", Toast.LENGTH_LONG)
            }
        }
    }
}
