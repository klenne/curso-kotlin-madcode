package br.com.celia.onclick

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener {
    //Terceira forma
    override fun onClick(v: View?) {
        val id = v!!.id

        if (id == R.id.btn_verificar){

            txv_boaTarde.text = "Deu certo!!"
        }else{

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Primeira forma onCLick
        //btn_verificar.setOnClickListener {
            //txv_boaTarde.text = "Humberto Barone"
        //}
        btn_verificar.setOnClickListener(this)

    }
    //Segunda forma
    //fun verificar(view: View){
        //txv_boaTarde.text = "Humberto Barone"
    ///}
}
