package br.com.podedirigir

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_tela2.*

class Tela2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela2)

        val nome= intent.getStringExtra("nome")
        //txv_nome.text= "Bem vindo $nome"
        txv_nome.text = txv_nome.text.toString()+" "+nome
        val hint = "Selecione uma idade!"
        var idades = arrayListOf<String>()
        idades.add(hint)
        for (idade in 1..100){
            idades.add("$idade")
        }

        val adapter = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,idades)
        spn_idade.adapter = adapter

        btn_verificar.setOnClickListener {

            if(spn_idade.isSelected && !spn_idade.isSelected.equals(hint)){
                var idade = spn_idade.selectedItem as Int
                if (idade >= 18) {
                    txv_resultado.text = "Pode dirigir!"
                } else {
                    txv_resultado.text = "Não pode dirigir!"
                }
            }else{
                Toast.makeText(this, "Selecione a idade!", Toast.LENGTH_LONG).show()
            }
        }
    }
}
